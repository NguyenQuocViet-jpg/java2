package Bai4;

public enum StudentType {
	REGULAR, 
	PART_TIME, 
	INTERNATIONAL
}
